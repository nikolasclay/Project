﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFlooringMastery.Models.Requests
{
    public class SaveCurrentOrderRequest
    {
        public Order Order { get; set; }
    }
}
