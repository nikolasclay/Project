﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFlooringMastery.Models.Requests
{
    public class SaveNewOrderRequest
    {
        public Order Order { get; set; }
    }
}
